// Code 16: data/local/ProductionEntity.kt

package com.elastictrack.pro.data.local

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "production_logs")
data class ProductionEntry(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val styleName: String,
    val netWeight: Double,
    val unitWeight: Double,
    val calculatedOutput: Int,
    val timestamp: Long = System.currentTimeMillis()
)