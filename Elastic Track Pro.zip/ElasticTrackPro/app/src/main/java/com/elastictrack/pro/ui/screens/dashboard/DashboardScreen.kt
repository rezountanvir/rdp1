// Code 69: ui/screens/dashboard/DashboardScreen.kt (Final Sync)

package com.elastictrack.pro.ui.screens.dashboard

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext // Ensure this is imported correctly
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.elastictrack.pro.data.local.AppDatabase
import com.elastictrack.pro.ui.theme.*

@Composable
fun DashboardScreen() {
    val context = LocalContext.current
    val db = AppDatabase.getDatabase(context)

    val orders by db.productionDao().getAllOrders().collectAsState(initial = emptyList())
    val productionLogs by db.productionDao().getAllLogs().collectAsState(initial = emptyList())
    val shipmentLogs by db.productionDao().getAllShipments().collectAsState(initial = emptyList())

    val totalProduced = productionLogs.sumOf { it.calculatedOutput }
    val totalShipped = shipmentLogs.sumOf { it.shippedQty }

    LazyColumn(
        modifier = Modifier.fillMaxSize().background(SoftGrayBg).padding(horizontal = 20.dp),
        contentPadding = PaddingValues(bottom = 100.dp)
    ) {
        item {
            Spacer(modifier = Modifier.height(20.dp))
            Text("Factory Overview", fontSize = 24.sp, fontWeight = FontWeight.Black)

            Row(modifier = Modifier.fillMaxWidth().padding(vertical = 15.dp), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                StatusCard("Today's Ready", "$totalProduced", EmeraldSuccess, Modifier.weight(1f))
                StatusCard("Total Shipped", "$totalShipped", ElectricIndigo, Modifier.weight(1f))
            }
        }

        item {
            Text("Buyer-wise Inventory Status", fontWeight = FontWeight.Bold, modifier = Modifier.padding(vertical = 10.dp))
        }

        items(orders) { order ->
            val buyerKey = "${order.buyerName} - ${order.stylePo}"
            val produced = productionLogs.filter { it.styleName == buyerKey }.sumOf { it.calculatedOutput }
            val shipped = shipmentLogs.filter { it.buyerName == buyerKey }.sumOf { it.shippedQty }

            BuyerStatusItem(buyerName = buyerKey, produced = produced, shipped = shipped)
            Spacer(modifier = Modifier.height(10.dp))
        }
    }
}

@Composable
fun StatusCard(label: String, value: String, color: Color, modifier: Modifier) {
    Surface(modifier = modifier, shape = RoundedCornerShape(20.dp), color = Color.White) {
        Column(modifier = Modifier.padding(16.dp)) {
            Text(label, fontSize = 11.sp, color = Color.Gray)
            Text(value, fontSize = 20.sp, fontWeight = FontWeight.Bold, color = color)
        }
    }
}

@Composable
fun BuyerStatusItem(buyerName: String, produced: Int, shipped: Int) {
    Surface(modifier = Modifier.fillMaxWidth(), shape = RoundedCornerShape(15.dp), color = Color.White) {
        Column(modifier = Modifier.padding(15.dp)) {
            Text(buyerName, fontWeight = FontWeight.Bold, color = DeepSlate)
            Spacer(modifier = Modifier.height(8.dp))
            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                Column {
                    Text("Produced", fontSize = 10.sp, color = Color.Gray)
                    Text("$produced", fontWeight = FontWeight.Bold, color = EmeraldSuccess)
                }
                Column {
                    Text("Shipped", fontSize = 10.sp, color = Color.Gray)
                    Text("$shipped", fontWeight = FontWeight.Bold, color = Color.Red)
                }
                Column {
                    Text("In Stock", fontSize = 10.sp, color = Color.Gray)
                    Text("${produced - shipped}", fontWeight = FontWeight.Bold, color = ElectricIndigo)
                }
            }
        }
    }
}