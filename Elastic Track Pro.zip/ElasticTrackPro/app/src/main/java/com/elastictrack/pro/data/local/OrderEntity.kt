// Code 61: data/local/OrderEntry.kt (Full Final)
package com.elastictrack.pro.data.local

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "active_orders")
data class OrderEntry(
    @PrimaryKey(autoGenerate = true)
    val id: Int = 0,
    val buyerName: String,
    val stylePo: String,
    val color: String,
    val totalLength: Double,
    val unit: String,
    val timestamp: Long = System.currentTimeMillis()
)