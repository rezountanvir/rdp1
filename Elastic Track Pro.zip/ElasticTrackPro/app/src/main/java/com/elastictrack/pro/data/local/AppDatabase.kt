// Code 45: data/local/AppDatabase.kt (Final Sync with Version 3)

package com.elastictrack.pro.data.local

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase

// এখানে আমরা ৩টি টেবিলই (Production, Order, Shipment) ইনক্লুড করেছি
@Database(
    entities = [ProductionEntry::class, OrderEntry::class, ShipmentEntry::class],
    version = 5,
    exportSchema = false
)
abstract class AppDatabase : RoomDatabase() {

    abstract fun productionDao(): ProductionDao

    companion object {
        @Volatile
        private var INSTANCE: AppDatabase? = null

        fun getDatabase(context: Context): AppDatabase {
            return INSTANCE ?: synchronized(this) {
                val instance = Room.databaseBuilder(
                    context.applicationContext,
                    AppDatabase::class.java,
                    "elastic_track_db"
                )
                    // ডাটাবেস ভার্সন পরিবর্তন হলে পুরনো ডাটা ডিলিট করে নতুন স্ট্রাকচার তৈরি করবে
                    .fallbackToDestructiveMigration()
                    .build()
                INSTANCE = instance
                instance
            }
        }
    }
}