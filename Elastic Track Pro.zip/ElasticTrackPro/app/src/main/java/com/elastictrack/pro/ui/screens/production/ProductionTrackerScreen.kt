// Code 71: ui/screens/production/ProductionTrackerScreen.kt (Full Fixed & Error Free)

package com.elastictrack.pro.ui.screens.production

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.elastictrack.pro.data.local.AppDatabase
import com.elastictrack.pro.data.local.ProductionEntry
import com.elastictrack.pro.ui.theme.*
import kotlinx.coroutines.launch

// ১. ক্লিক হেল্পার ফাংশন (Fix for Screenshot 2 & 7)
@Composable
fun Modifier.noRippleClickable(onClick: () -> Unit): Modifier {
    val interactionSource = remember { MutableInteractionSource() }
    return this.then(
        Modifier.clickable(
            indication = null,
            interactionSource = interactionSource
        ) { onClick() }
    )
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ProductionTrackerScreen() {
    val context = LocalContext.current
    val db = AppDatabase.getDatabase(context)
    val scope = rememberCoroutineScope()

    val orders by db.productionDao().getAllOrders().collectAsState(initial = emptyList())
    val productionLogs by db.productionDao().getAllLogs().collectAsState(initial = emptyList())

    var selectedStyle by remember { mutableStateOf("") }
    var netWeight by remember { mutableStateOf("") }
    var unitWeightGram by remember { mutableStateOf("") }
    var expanded by remember { mutableStateOf(false) }

    val calculatedOutput = remember(netWeight, unitWeightGram) {
        val w = netWeight.toDoubleOrNull() ?: 0.0
        val u = unitWeightGram.toDoubleOrNull() ?: 0.0
        if (u > 0) (w * 1000) / u else 0.0
    }

    LazyColumn(
        modifier = Modifier.fillMaxSize().background(SoftGrayBg).padding(horizontal = 20.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp),
        contentPadding = PaddingValues(bottom = 100.dp)
    ) {
        item {
            Spacer(modifier = Modifier.height(20.dp))
            Text("Production Output", fontSize = 24.sp, fontWeight = FontWeight.Black)

            Surface(modifier = Modifier.padding(top = 10.dp), shape = RoundedCornerShape(24.dp), color = Color.White) {
                Column(modifier = Modifier.padding(20.dp)) {

                    // ড্রপডাউন মেনু
                    ExposedDropdownMenuBox(expanded = expanded, onExpandedChange = { expanded = !expanded }) {
                        OutlinedTextField(
                            value = selectedStyle, onValueChange = {}, readOnly = true,
                            label = { Text("Select Elastic Contract") },
                            trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded = expanded) },
                            modifier = Modifier.menuAnchor().fillMaxWidth(), shape = RoundedCornerShape(12.dp)
                        )
                        ExposedDropdownMenu(expanded = expanded, onDismissRequest = { expanded = false }) {
                            orders.forEach { order ->
                                DropdownMenuItem(
                                    text = { Text("${order.buyerName} - ${order.stylePo}") },
                                    onClick = { selectedStyle = "${order.buyerName} - ${order.stylePo}"; expanded = false }
                                )
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(12.dp))

                    Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                        OutlinedTextField(value = netWeight, onValueChange = { netWeight = it }, label = { Text("Weight (KG)") }, modifier = Modifier.weight(1f))
                        OutlinedTextField(value = unitWeightGram, onValueChange = { unitWeightGram = it }, label = { Text("Gram/Mtr") }, modifier = Modifier.weight(1f))
                    }

                    Spacer(modifier = Modifier.height(20.dp))

                    // আউটপুট ক্যালকুলেশন বক্স (Fix for Screenshot 6 - Alignment Error)
                    Surface(modifier = Modifier.fillMaxWidth(), color = ElectricIndigo, shape = RoundedCornerShape(16.dp)) {
                        Column(
                            modifier = Modifier.padding(16.dp),
                            horizontalAlignment = Alignment.CenterHorizontally // এখানে horizontalAlignment ব্যবহার করা হয়েছে
                        ) {
                            Text("GOOD PRODUCTION CALCULATION", color = Color.White.copy(alpha = 0.7f), fontSize = 10.sp)
                            Text("${calculatedOutput.toInt()} Meters", color = Color.White, fontSize = 24.sp, fontWeight = FontWeight.Bold)
                        }
                    }

                    Spacer(modifier = Modifier.height(16.dp))

                    Button(
                        onClick = {
                            if (selectedStyle.isNotEmpty()) {
                                scope.launch {
                                    db.productionDao().insertLog(ProductionEntry(
                                        styleName = selectedStyle,
                                        netWeight = netWeight.toDoubleOrNull() ?: 0.0,
                                        unitWeight = unitWeightGram.toDoubleOrNull() ?: 0.0,
                                        calculatedOutput = calculatedOutput.toInt()
                                    ))
                                    netWeight = ""; unitWeightGram = ""
                                }
                            }
                        },
                        modifier = Modifier.fillMaxWidth().height(56.dp),
                        colors = ButtonDefaults.buttonColors(containerColor = ElectricIndigo),
                        shape = RoundedCornerShape(12.dp)
                    ) { Text("Confirm & Save Production", color = Color.White) }
                }
            }
        }

        items(productionLogs) { log ->
            ProductionHistoryItem(log = log, onDelete = { scope.launch { db.productionDao().deleteLog(log) } })
        }
    }
}

@Composable
fun ProductionHistoryItem(log: ProductionEntry, onDelete: () -> Unit) {
    Surface(modifier = Modifier.fillMaxWidth(), shape = RoundedCornerShape(15.dp), color = Color.White) {
        Row(modifier = Modifier.padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
            Column(modifier = Modifier.weight(1f)) {
                Text(log.styleName, fontWeight = FontWeight.Bold)
                Text("${log.netWeight} KG / ${log.unitWeight}g", fontSize = 12.sp, color = Color.Gray)
            }
            Text("${log.calculatedOutput}m", fontWeight = FontWeight.Bold, color = EmeraldSuccess)

            // ডিলিট বাটন (Fix for Screenshot 2/7 usage)
            IconButton(onClick = onDelete) {
                Icon(Icons.Default.Delete, contentDescription = "Delete", tint = RoseWarning)
            }
        }
    }
}