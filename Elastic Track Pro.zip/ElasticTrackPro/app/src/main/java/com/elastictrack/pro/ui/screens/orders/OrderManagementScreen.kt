// Code 72: ui/screens/orders/OrderManagementScreen.kt (Dialog & Keyboard Navigation Fixed)

package com.elastictrack.pro.ui.screens.orders

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.focus.FocusDirection
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalFocusManager
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import com.elastictrack.pro.data.local.AppDatabase
import com.elastictrack.pro.data.local.OrderEntry
import com.elastictrack.pro.ui.theme.*
import kotlinx.coroutines.launch

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun OrderManagementScreen() {
    val context = LocalContext.current
    val db = AppDatabase.getDatabase(context)
    val scope = rememberCoroutineScope()

    val orderList by db.productionDao().getAllOrders().collectAsState(initial = emptyList())

    // পপআপ ডায়ালগ স্টেট
    var showDialog by remember { mutableStateOf(false) }
    var selectedOrder by remember { mutableStateOf<OrderEntry?>(null) }

    Scaffold(
        floatingActionButton = {
            ExtendedFloatingActionButton(
                onClick = {
                    selectedOrder = null
                    showDialog = true
                },
                containerColor = ElectricIndigo,
                contentColor = Color.White,
                shape = RoundedCornerShape(16.dp),
                icon = { Icon(Icons.Default.Add, null) },
                text = { Text("Add New Order") }
            )
        }
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .background(SoftGrayBg)
                .padding(padding)
                .padding(horizontal = 20.dp)
        ) {
            Spacer(modifier = Modifier.height(20.dp))
            Text("Order History", fontSize = 24.sp, fontWeight = FontWeight.Black, color = DeepSlate)
            Text("Manage your jacquard elastic orders", color = Color.Gray, fontSize = 14.sp)

            Spacer(modifier = Modifier.height(16.dp))

            if (orderList.isEmpty()) {
                Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                    Text("No orders found.", color = Color.Gray)
                }
            } else {
                LazyColumn(
                    verticalArrangement = Arrangement.spacedBy(12.dp),
                    contentPadding = PaddingValues(bottom = 100.dp)
                ) {
                    items(orderList) { order ->
                        OrderItemCard(
                            order = order,
                            onEdit = {
                                selectedOrder = order
                                showDialog = true
                            },
                            onDelete = {
                                scope.launch { db.productionDao().deleteOrder(order) }
                            }
                        )
                    }
                }
            }
        }
    }

    // স্ক্রিনে ভেসে ওঠা পপআপ (Dialog)
    if (showDialog) {
        Dialog(onDismissRequest = { showDialog = false }) {
            OrderDialogContent(
                existingOrder = selectedOrder,
                onSave = { order ->
                    scope.launch {
                        db.productionDao().insertOrder(order)
                        showDialog = false
                    }
                },
                onCancel = { showDialog = false }
            )
        }
    }
}

@Composable
fun OrderDialogContent(
    existingOrder: OrderEntry?,
    onSave: (OrderEntry) -> Unit,
    onCancel: () -> Unit
) {
    val focusManager = LocalFocusManager.current
    var buyer by remember { mutableStateOf(existingOrder?.buyerName ?: "") }
    var style by remember { mutableStateOf(existingOrder?.stylePo ?: "") }
    var colorName by remember { mutableStateOf(existingOrder?.color ?: "") }
    var length by remember { mutableStateOf(existingOrder?.totalLength?.toString() ?: "") }
    var unit by remember { mutableStateOf(existingOrder?.unit ?: "Yards") }

    Surface(
        shape = RoundedCornerShape(24.dp),
        color = Color.White,
        modifier = Modifier.fillMaxWidth().padding(10.dp)
    ) {
        Column(
            modifier = Modifier.padding(24.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            Text(
                text = if (existingOrder == null) "New Order" else "Edit Order",
                fontSize = 20.sp,
                fontWeight = FontWeight.Bold,
                color = DeepSlate
            )

            // ১. বায়ার নেম - এন্টার চাপলে নিচে যাবে
            OutlinedTextField(
                value = buyer, onValueChange = { buyer = it },
                label = { Text("Buyer Name") },
                modifier = Modifier.fillMaxWidth(),
                keyboardOptions = KeyboardOptions(imeAction = ImeAction.Next),
                keyboardActions = KeyboardActions(onNext = { focusManager.moveFocus(FocusDirection.Down) }),
                shape = RoundedCornerShape(12.dp)
            )

            // ২. স্টাইল - এন্টার চাপলে পাশে যাবে (ডানে)
            OutlinedTextField(
                value = style, onValueChange = { style = it },
                label = { Text("Style/PO") },
                modifier = Modifier.fillMaxWidth(),
                keyboardOptions = KeyboardOptions(imeAction = ImeAction.Next),
                keyboardActions = KeyboardActions(onNext = { focusManager.moveFocus(FocusDirection.Down) }),
                shape = RoundedCornerShape(12.dp)
            )

            // ৩. কালার
            OutlinedTextField(
                value = colorName, onValueChange = { colorName = it },
                label = { Text("Color") },
                modifier = Modifier.fillMaxWidth(),
                keyboardOptions = KeyboardOptions(imeAction = ImeAction.Next),
                keyboardActions = KeyboardActions(onNext = { focusManager.moveFocus(FocusDirection.Down) }),
                shape = RoundedCornerShape(12.dp)
            )

            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                // ৪. লেন্থ - নাম্বার কিবোর্ড
                OutlinedTextField(
                    value = length, onValueChange = { length = it },
                    label = { Text("Qty") },
                    modifier = Modifier.weight(1f),
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number, imeAction = ImeAction.Next),
                    keyboardActions = KeyboardActions(onNext = { focusManager.moveFocus(FocusDirection.Right) }),
                    shape = RoundedCornerShape(12.dp)
                )
                // ৫. ইউনিট
                OutlinedTextField(
                    value = unit, onValueChange = { unit = it },
                    label = { Text("Unit") },
                    modifier = Modifier.weight(1f),
                    keyboardOptions = KeyboardOptions(imeAction = ImeAction.Done),
                    keyboardActions = KeyboardActions(onDone = { focusManager.clearFocus() }),
                    shape = RoundedCornerShape(12.dp)
                )
            }

            Spacer(modifier = Modifier.height(10.dp))

            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                TextButton(onClick = onCancel, modifier = Modifier.weight(1f)) {
                    Text("Cancel", color = Color.Gray)
                }
                Button(
                    onClick = {
                        if (buyer.isNotEmpty() && style.isNotEmpty()) {
                            onSave(OrderEntry(
                                id = existingOrder?.id ?: 0,
                                buyerName = buyer, stylePo = style,
                                color = colorName, totalLength = length.toDoubleOrNull() ?: 0.0,
                                unit = unit
                            ))
                        }
                    },
                    modifier = Modifier.weight(2f),
                    colors = ButtonDefaults.buttonColors(containerColor = ElectricIndigo),
                    shape = RoundedCornerShape(12.dp)
                ) {
                    Text("Save Order")
                }
            }
        }
    }
}

@Composable
fun OrderItemCard(order: OrderEntry, onEdit: () -> Unit, onDelete: () -> Unit) {
    Surface(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(20.dp),
        color = Color.White,
        shadowElevation = 1.dp
    ) {
        Row(
            modifier = Modifier.padding(16.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column(modifier = Modifier.weight(1f)) {
                Text(order.buyerName, fontWeight = FontWeight.Bold, fontSize = 16.sp, color = DeepSlate)
                Text("Style: ${order.stylePo} | Color: ${order.color}", fontSize = 12.sp, color = Color.Gray)
                Text("${order.totalLength} ${order.unit}", fontWeight = FontWeight.Bold, color = ElectricIndigo)
            }
            Row {
                IconButton(onClick = onEdit) { Icon(Icons.Default.Edit, null, tint = Color.Gray, modifier = Modifier.size(20.dp)) }
                IconButton(onClick = onDelete) { Icon(Icons.Default.Delete, null, tint = RoseWarning, modifier = Modifier.size(20.dp)) }
            }
        }
    }
}