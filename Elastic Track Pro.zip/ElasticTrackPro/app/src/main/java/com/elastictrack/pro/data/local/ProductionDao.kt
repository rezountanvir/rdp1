// Code 42: data/local/ProductionDao.kt (Full Final Sync)

package com.elastictrack.pro.data.local

import androidx.room.*
import kotlinx.coroutines.flow.Flow

@Dao
interface ProductionDao {

    // --- Production Logs ---
    @Insert suspend fun insertLog(entry: ProductionEntry)
    @Delete suspend fun deleteLog(entry: ProductionEntry) // ডিলিট সুবিধা যোগ করা হয়েছে
    @Query("SELECT * FROM production_logs ORDER BY timestamp DESC")
    fun getAllLogs(): Flow<List<ProductionEntry>>

    // --- Order Management ---
    @Insert suspend fun insertOrder(order: OrderEntry)
    @Update suspend fun updateOrder(order: OrderEntry)
    @Delete suspend fun deleteOrder(order: OrderEntry)
    @Query("SELECT * FROM active_orders ORDER BY id DESC")
    fun getAllOrders(): Flow<List<OrderEntry>>

    // --- Shipment ---
    @Insert suspend fun insertShipment(shipment: ShipmentEntry)
    @Query("SELECT * FROM shipment_records ORDER BY timestamp DESC")
    fun getAllShipments(): Flow<List<ShipmentEntry>>
}