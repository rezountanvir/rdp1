// Code 53: ui/MainScreen.kt (Full Updated with Logout Functionality)

package com.elastictrack.pro.ui

import android.content.Context
import androidx.compose.foundation.layout.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.elastictrack.pro.ui.screens.dashboard.DashboardScreen
import com.elastictrack.pro.ui.screens.orders.OrderManagementScreen
import com.elastictrack.pro.ui.screens.production.ProductionTrackerScreen
import com.elastictrack.pro.ui.screens.shipment.ShipmentScreen
import com.elastictrack.pro.ui.theme.DeepSlate
import com.elastictrack.pro.ui.theme.ElectricIndigo

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun MainScreen(onLogout: () -> Unit = {}) {
    var selectedTab by remember { mutableIntStateOf(0) }
    val context = LocalContext.current
    var showLogoutDialog by remember { mutableStateOf(false) }

    // লগআউট ডায়ালগ কনফার্মেশন
    if (showLogoutDialog) {
        AlertDialog(
            onDismissRequest = { showLogoutDialog = false },
            title = { Text("Logout") },
            text = { Text("Are you sure you want to logout from the app?") },
            confirmButton = {
                TextButton(onClick = {
                    val sharedPref = context.getSharedPreferences("user_prefs", Context.MODE_PRIVATE)
                    sharedPref.edit().putBoolean("is_logged_in", false).apply()
                    showLogoutDialog = false
                    // অ্যাপ রিস্টার্ট বা লগইন স্ক্রিনে পাঠানোর জন্য কলব্যাক
                    onLogout()
                }) {
                    Text("Logout", color = Color.Red)
                }
            },
            dismissButton = {
                TextButton(onClick = { showLogoutDialog = false }) {
                    Text("Cancel")
                }
            }
        )
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Text("ElasticTrack Pro", fontWeight = FontWeight.Black, fontSize = 20.sp)
                },
                actions = {
                    IconButton(onClick = { showLogoutDialog = true }) {
                        Icon(
                            imageVector = Icons.Default.AccountCircle,
                            contentDescription = "Profile/Logout",
                            modifier = Modifier.size(32.dp),
                            tint = ElectricIndigo
                        )
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = Color.White)
            )
        },
        bottomBar = {
            NavigationBar(containerColor = Color.White) {
                NavigationBarItem(
                    selected = selectedTab == 0,
                    onClick = { selectedTab = 0 },
                    icon = { Icon(Icons.Default.GridView, "Home") },
                    label = { Text("HOME") }
                )
                NavigationBarItem(
                    selected = selectedTab == 1,
                    onClick = { selectedTab = 1 },
                    icon = { Icon(Icons.Default.History, "Orders") },
                    label = { Text("ORDERS") }
                )
                NavigationBarItem(
                    selected = selectedTab == 2,
                    onClick = { selectedTab = 2 },
                    icon = { Icon(Icons.Default.BarChart, "Produce") },
                    label = { Text("PRODUCE") }
                )
                NavigationBarItem(
                    selected = selectedTab == 3,
                    onClick = { selectedTab = 3 },
                    icon = { Icon(Icons.Default.LocalShipping, "Ship") },
                    label = { Text("SHIP") }
                )
            }
        }
    ) { innerPadding ->
        Box(modifier = Modifier.padding(innerPadding)) {
            when (selectedTab) {
                0 -> DashboardScreen()
                1 -> OrderManagementScreen()
                2 -> ProductionTrackerScreen()
                3 -> ShipmentScreen()
            }
        }
    }
}