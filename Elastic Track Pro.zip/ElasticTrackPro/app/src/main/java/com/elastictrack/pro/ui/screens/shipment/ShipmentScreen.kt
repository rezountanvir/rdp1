// Code 65: ui/screens/shipment/ShipmentScreen.kt (Stock Logic Updated)

package com.elastictrack.pro.ui.screens.shipment

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.elastictrack.pro.data.local.AppDatabase
import com.elastictrack.pro.data.local.ShipmentEntry
import com.elastictrack.pro.ui.theme.*
import kotlinx.coroutines.launch

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ShipmentScreen() {
    val context = LocalContext.current
    val db = AppDatabase.getDatabase(context)
    val scope = rememberCoroutineScope()

    val orders by db.productionDao().getAllOrders().collectAsState(initial = emptyList())
    val shipments by db.productionDao().getAllShipments().collectAsState(initial = emptyList())
    val productionLogs by db.productionDao().getAllLogs().collectAsState(initial = emptyList())

    var selectedOrder by remember { mutableStateOf("") }
    var shippedQty by remember { mutableStateOf("") }
    var vehicleNo by remember { mutableStateOf("") }
    var expanded by remember { mutableStateOf(false) }

    // স্টক ক্যালকুলেশন লজিক
    val currentStock = remember(selectedOrder, productionLogs, shipments) {
        val totalProduced = productionLogs.filter { it.styleName == selectedOrder }.sumOf { it.calculatedOutput }
        val totalShipped = shipments.filter { it.buyerName == selectedOrder }.sumOf { it.shippedQty }
        totalProduced - totalShipped
    }

    LazyColumn(
        modifier = Modifier.fillMaxSize().background(SoftGrayBg).padding(horizontal = 20.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp),
        contentPadding = PaddingValues(bottom = 100.dp)
    ) {
        item {
            Spacer(modifier = Modifier.height(20.dp))
            Text("Shipment & Inventory", fontSize = 24.sp, fontWeight = FontWeight.Black)

            Row(modifier = Modifier.fillMaxWidth().padding(vertical = 10.dp), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                // স্টক কার্ড
                Surface(modifier = Modifier.weight(1f), shape = RoundedCornerShape(20.dp), color = Color.White) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Text("Stock in Warehouse", fontSize = 10.sp, color = Color.Gray)
                        Text("$currentStock Units", fontSize = 18.sp, fontWeight = FontWeight.Bold, color = EmeraldSuccess)
                    }
                }
                // মোট শিপমেন্ট কার্ড
                Surface(modifier = Modifier.weight(1f), shape = RoundedCornerShape(20.dp), color = ElectricIndigo) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Text("Total Shipped", fontSize = 10.sp, color = Color.White.copy(0.7f))
                        Text("${shipments.sumOf { it.shippedQty }} Units", fontSize = 18.sp, fontWeight = FontWeight.Bold, color = Color.White)
                    }
                }
            }
        }

        item {
            Surface(modifier = Modifier.fillMaxWidth(), shape = RoundedCornerShape(24.dp), color = Color.White) {
                Column(modifier = Modifier.padding(24.dp)) {
                    Text("New Dispatch", fontWeight = FontWeight.Bold)
                    Spacer(modifier = Modifier.height(16.dp))

                    ExposedDropdownMenuBox(expanded = expanded, onExpandedChange = { expanded = !expanded }) {
                        OutlinedTextField(
                            value = selectedOrder, onValueChange = {}, readOnly = true,
                            label = { Text("Select Buyer/Style") },
                            trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded = expanded) },
                            modifier = Modifier.menuAnchor().fillMaxWidth(), shape = RoundedCornerShape(12.dp)
                        )
                        ExposedDropdownMenu(expanded = expanded, onDismissRequest = { expanded = false }) {
                            orders.forEach { order ->
                                DropdownMenuItem(
                                    text = { Text("${order.buyerName} - ${order.stylePo}") },
                                    onClick = { selectedOrder = "${order.buyerName} - ${order.stylePo}"; expanded = false }
                                )
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(16.dp))
                    OutlinedTextField(
                        value = shippedQty, onValueChange = { shippedQty = it },
                        label = { Text("Quantity to Ship") },
                        modifier = Modifier.fillMaxWidth(), shape = RoundedCornerShape(12.dp)
                    )
                    Spacer(modifier = Modifier.height(16.dp))
                    OutlinedTextField(
                        value = vehicleNo, onValueChange = { vehicleNo = it },
                        label = { Text("Vehicle No") },
                        modifier = Modifier.fillMaxWidth(), shape = RoundedCornerShape(12.dp)
                    )
                    Spacer(modifier = Modifier.height(20.dp))

                    Button(
                        onClick = {
                            if (selectedOrder.isNotEmpty() && shippedQty.isNotEmpty()) {
                                scope.launch {
                                    db.productionDao().insertShipment(ShipmentEntry(buyerName = selectedOrder, vehicleNo = vehicleNo, shippedQty = shippedQty.toIntOrNull() ?: 0))
                                    shippedQty = ""; vehicleNo = ""
                                }
                            }
                        },
                        modifier = Modifier.fillMaxWidth().height(50.dp),
                        colors = ButtonDefaults.buttonColors(containerColor = ElectricIndigo)
                    ) { Text("Confirm Dispatch") }
                }
            }
        }

        items(shipments) { shipment ->
            Surface(modifier = Modifier.fillMaxWidth(), shape = RoundedCornerShape(15.dp), color = Color.White) {
                Row(modifier = Modifier.padding(15.dp), verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Default.LocalShipping, null, tint = Color.Gray)
                    Spacer(modifier = Modifier.width(15.dp))
                    Column(modifier = Modifier.weight(1f)) {
                        Text(shipment.buyerName, fontWeight = FontWeight.Bold, fontSize = 14.sp)
                        Text("Veh: ${shipment.vehicleNo}", fontSize = 11.sp, color = Color.Gray)
                    }
                    Text("-${shipment.shippedQty}", fontWeight = FontWeight.Bold, color = Color.Red)
                }
            }
        }
    }
}