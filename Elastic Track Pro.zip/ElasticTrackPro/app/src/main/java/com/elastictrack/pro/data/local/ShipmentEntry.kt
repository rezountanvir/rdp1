// Code 50: data/local/ShipmentEntry.kt (Updated for Code 49)

package com.elastictrack.pro.data.local

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "shipment_records")
data class ShipmentEntry(
    @PrimaryKey(autoGenerate = true)
    val id: Int = 0,               // ইউনিক আইডি
    val orderId: String = "",      // অর্ডারের আইডি (ঐচ্ছিক)
    val buyerName: String,         // ড্রপডাউন থেকে আসা বায়ার এবং স্টাইল নেম
    val vehicleNo: String,         // গাড়ি বা ড্রাইভারে তথ্য (Screen 1097 অনুযায়ী)
    val shippedQty: Int,           // কতটুকু পাঠানো হলো (Units)
    val destination: String = "",  // গন্তব্য (যদি প্রয়োজন হয়)
    val timestamp: Long = System.currentTimeMillis() // সেভ করার সময়
)