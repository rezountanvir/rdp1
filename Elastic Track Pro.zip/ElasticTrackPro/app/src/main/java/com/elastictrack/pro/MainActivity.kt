// Code 76: MainActivity.kt (Theme & Navigation Fixed)

package com.elastictrack.pro

import android.content.Context
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import com.elastictrack.pro.ui.screens.dashboard.DashboardScreen
import com.elastictrack.pro.ui.screens.login.LoginScreen
import com.elastictrack.pro.ui.screens.orders.OrderManagementScreen
import com.elastictrack.pro.ui.screens.production.ProductionTrackerScreen
import com.elastictrack.pro.ui.screens.shipment.ShipmentScreen
// আপনার থিম ফাইলের নাম অনুযায়ী নিচের ইমপোর্টটি অটো-কারেক্ট করে নিন
import com.elastictrack.pro.ui.theme.* class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val sharedPref = getSharedPreferences("user_prefs", Context.MODE_PRIVATE)
        val isLoggedIn = sharedPref.getBoolean("is_logged_in", false)

        setContent {
            // যদি ElasticTrackTheme লাল হয়ে থাকে, তবে এটি কেটে দিয়ে শুধু MaterialTheme { ... } ব্যবহার করতে পারেন
            MaterialTheme {
                val navController = rememberNavController()
                val startDestination = if (isLoggedIn) "main_app" else "login"

                NavHost(navController = navController, startDestination = startDestination) {
                    composable("login") {
                        LoginScreen(onLoginSuccess = {
                            sharedPref.edit().putBoolean("is_logged_in", true).apply()
                            navController.navigate("main_app") {
                                popUpTo("login") { inclusive = true }
                            }
                        })
                    }
                    composable("main_app") {
                        MainAppContainer()
                    }
                }
            }
        }
    }
}

@Composable
fun MainAppContainer() {
    var selectedItem by remember { mutableIntStateOf(0) }

    val items = listOf("Home", "Orders", "Produce", "Ship")
    val icons = listOf(
        Icons.Default.GridView,
        Icons.Default.History,
        Icons.Default.PrecisionManufacturing,
        Icons.Default.LocalShipping
    )

    Scaffold(
        bottomBar = {
            NavigationBar(
                containerColor = Color.White,
                tonalElevation = 8.dp
            ) {
                items.forEachIndexed { index, item ->
                    NavigationBarItem(
                        icon = { Icon(icons[index], contentDescription = item) },
                        label = { Text(item) },
                        selected = selectedItem == index,
                        onClick = { selectedItem = index },
                        colors = NavigationBarItemDefaults.colors(
                            selectedIconColor = Color(0xFF6366F1),
                            unselectedIconColor = Color.Gray,
                            indicatorColor = Color(0xFFF3F4F6)
                        )
                    )
                }
            }
        }
    ) { innerPadding ->
        Box(modifier = Modifier.padding(innerPadding)) {
            when (selectedItem) {
                0 -> DashboardScreen()
                1 -> OrderManagementScreen()
                2 -> ProductionTrackerScreen()
                3 -> ShipmentScreen()
            }
        }
    }
}